import{b as e}from"./js-beautify-147be88f.js";const r=r=>e(r.replace(/^\/\/.*$/gm,"").replace(/[\n\t\r]/g,""),{indent_size:4});export{r as f};
