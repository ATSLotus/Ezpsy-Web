// 1.输出 console
