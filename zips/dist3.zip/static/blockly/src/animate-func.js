//1.ezAnimate
function EzAnimate(el,delay,func)
{
    ez.animate(el,func,delay)
}