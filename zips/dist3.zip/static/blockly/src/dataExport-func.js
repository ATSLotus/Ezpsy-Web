/*
 * @Author: ATSLotus/时桐
 * @Date: 2022-05-12 16:00:40
 * @LastEditors: ATSLotus/时桐
 * @LastEditTime: 2022-09-21 09:37:45
 * @Description: 
 * @FilePath: /ezpsy/public/static/js/ezpsy/blockly-src/dataExport-func.js
 */

//因serverless废弃此方法

// function AjaxData(id,url,name,data){
    // $.ajax({
    //     type: 'post',
    //     url: url,
    //     data: {
    //         name: name,
    //         userId: id,
    //         data: `${data}`
    //     }, 
    //     success: e =>{
    //         console.dir(e)
    //     }
    // })
// }