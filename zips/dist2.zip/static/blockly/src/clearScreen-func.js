// 1.清屏
let clear_canvas=function(x,y,width,height){
    // ctx.clearRect(x, y, width, height);
    // var ul=document.body;
    // ul.removeChild(ul.children[i]);
    ez.clear();
}