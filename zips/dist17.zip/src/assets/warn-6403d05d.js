const r=""+new URL("warn-f6175b2f.svg",import.meta.url).href;export{r as _};
